# Gameplay Recorder: source questions task

This folder holds C# scripts of a Unity game whose recording was exported earlier and rebuilt by another AI as a small playable ad. That rebuild could not reproduce some behaviours from the recording and the brief, and asks about them in `source-questions.json`. It never sees these scripts.

Your job: answer each question in plain prose with the rules, formulas and constants the code uses, so the rebuild can make the game behave the same way. One short document, `answers.md`.

This is a task of minutes. Read what the questions need, write the answers, check them, finish.

## Rules that are checked

1. Work only in this folder. Read no other file of the project, upload nothing, and do not change or delete any `.cs` file, this prompt, `SOURCE_MAP.md`, `source-questions.json` or `script_processing_job.json`. Running the Orvind Exporter launcher, when you have it, is fine.
2. Your output is one Markdown file written directly into this folder: `answers.md`. If it is already there, it is yours to complete or replace.
3. Its first line is exactly `<!-- source-answers-v1 -->`, then the title `# Answers to source questions`, then one section per question, headed `## Q1`, `## Q2` and so on with the question's `id` and nothing else on the heading line, each id once, in any order, and no other second-level heading. Every section has an answer.
4. No source code in your output:
   - no code blocks, no lines of C#, no method signatures, no statements with braces or semicolons;
   - never eight or more words, names or numbers in a row in the order they have on one line of a source. Say it in your own words. The check compares runs of letters, digits and underscores, ignoring case and punctuation, with every line of every source, comments and strings included;
   - type, field, method, tag, layer and animation names are fine, with or without backticks, and so are numbers.
5. No secrets and no personal data, even when the code contains them: no keys, tokens, passwords, URLs, e-mail addresses, account, bundle or ad-unit identifiers.
6. No absolute file paths. Paths of sources relative to the project, such as those in `source-questions.json`, are fine.
7. Finish with the result file, exactly as described under "Finish".

## The questions

Each entry of `questions` in `source-questions.json` has:

- `id`: the heading of its answer.
- `behavior`: what the player sees that the rebuild could not reproduce.
- `evidence`: where in the recording it shows (a video time, a gesture). You have no recording here; it only tells you which moment is meant.
- `files`: the sources most likely to hold the answer, as project paths. Each source of this folder keeps its project path below it (`Assets/...`), and `SOURCE_MAP.md` lists them all with what they declare and use; its remarks about `_index.md` do not apply here. The list may be empty or incomplete: follow the code from there.
- `ask`: what the rebuild needs: a rule, a formula or constants.

## What an answer holds

- The rule as the code applies it, step by step in the order it runs each frame or on each event, in your own words.
- Every formula with its inputs named and their values: recorded values from `SOURCE_MAP.md` first, otherwise the code's constants or defaults, saying which.
- For every relation ("relative to", "against", "per", "times", "a fraction of"), what the code multiplies or divides by, checked in the code. A size computed from an object's own base scale and then fitted to a container is not a size relative to the container.
- Units, limits, clamps, easing and durations, and the conditions under which the behaviour starts and stops.
- The types and methods the answer comes from, by name, so a reader can tell where it was found.
- When the answer depends on data that is not in these sources (a prefab value that was not recorded, an animation clip, a physics material, a shader), say so in one line and name what holds it.
- When the code does not determine the answer, write "not determinable from the code" and one line on what you checked. Do not guess.

Answer what is asked and what the rebuild needs to act on it; leave out the rest of the game.

## Finish

With the Orvind Exporter launcher (the `orvind-export` skill):

1. Run its `check` command for this job. It applies the recorder's validation without finishing anything. Fix what it rejects and run it again until it passes.
2. Run its `complete` command. It signs off the answers for you (it writes the result file described below) and copies `answers.md` into the export folder.

Without the launcher:

1. Read `script_processing_job.json` and keep its `token`.
2. Write `script_processing_result.json.tmp` containing `{"v":1,"status":"complete","token":"<token of the job file>"}`, with nothing else in it, and rename it to `script_processing_result.json`. This is your last change in the folder: the result file must be the newest file in it.

Then, unless the skill you are following says what to report, tell the user in two or three lines: how many questions you answered and which ones the code does not determine.
