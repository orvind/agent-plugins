# Gameplay Recorder: script logic task

This folder holds the C# scripts of a Unity game, exported next to a recording of that game being played (video, scene, assets, object and input timelines). Another AI will rebuild the recorded gameplay as a small playable ad. It gets the recording. It never sees these scripts.

Your job: write down, in plain prose and numbers, the game logic and the constants that rebuild needs and that the recording alone cannot show. One short brief, not a document per script.

This is a task of minutes. Read what matters, write the brief, check it, finish.

## Rules that are checked

1. Work only in this folder. Read no other file of the project, upload nothing, and do not change or delete any `.cs` file, this prompt, `SOURCE_MAP.md` or `script_processing_job.json`. Running the Orvind Exporter launcher, when you have it, is fine.
2. Your output is Markdown written directly into this folder: `_index.md` and `_project_behavior.md`. Add a topic document only when the rules below say so.
3. Every Markdown file you write starts with this exact first line:
   `<!-- playable-script-analysis-md-v4 -->`
   A Markdown file that starts with such a marker line is output of an earlier attempt and yours to replace. Leave any other file alone.
4. No source code in your output:
   - no code blocks, no lines of C#, no method signatures, no statements with braces or semicolons;
   - never eight or more words, names or numbers in a row in the order they have on one line of a source. Say it in your own words. When you list names (enum values, fields, cases), do not reproduce a long list in source order: group them, reorder them, or split the sentence. The check compares runs of letters, digits and underscores, ignoring case and punctuation, with every line of every source, comments and strings included;
   - type, field, method, tag, layer and animation names are fine, with or without backticks, and so are numbers.
5. No secrets and no personal data, even when the code contains them: no keys, tokens, passwords, URLs, e-mail addresses, account, bundle or ad-unit identifiers.
6. No absolute file paths. Object names from the source map, such as `Barn/SellPoint/Block(Clone)`, are not file paths and are fine.
7. Finish with the result file, exactly as described under "Finish".

## Start from the source map

`SOURCE_MAP.md`, when present, was written by the recorder for you:

- One row per source: size, declared types, the Unity entry points it has, the kinds of API it touches ("Signals"), which recorded objects carry it, which other sources it uses, and a "Hint" (core, supporting, minor, platform or SDK, editor only). The hint is a guess from the shape of the code. You decide.
- A source without recorded objects is on no object: code the others call into, such as rules, progress, data classes and helpers. "None left at the end" means its objects were destroyed, or their scene was left, before the recording ended: there are no recorded values for it.
- "Recorded values": what each component held when the recording ended, and the data assets it points at. These are the values the game ran with. Use them. A default written in a source is only a default.
- They are a snapshot of the end of the recording. A field marked "the code changes it during play" (a score, a counter, a timer) shows where it ended, so take its starting value from the code. A field marked "no source reads it" changes nothing: leave it out.
- A reference listed as "not assigned" is empty in the scene. Code that needs that object does nothing there: describe what this scene does, not what the code could do.

Decide what to read from it:

- Follow the game, not the file list. Start at the player's input, follow what it triggers, and stop when you reach the win, the loss and the restart.
- When the sources are under about 1,000 lines in total, read them all and skip the triage.
- Read in full the sources that drive the recorded gameplay. They are usually among those hinted core, but a hint is not a reason to read: a menu or hub controller, a result card or a sound manager can look core and matter for a few lines only.
- Read supporting ones for the events and numbers they add.
- A large source can matter for one small part (a menu controller that also starts the level): read that part and search the rest.
- The rest: when the name, the types and the signals already say what a source is (a safe-area fitter, a canvas scaler, a button effect), do not open it. Otherwise open its first screenful to confirm that it does not change how the game plays.
- Read several files in one step when your tools allow it. This task is mostly reading.

## What the rebuild needs

The scope is the recorded session: the level that was played and the scenes the recording went through. Rules and numbers for content the recording never reaches (another material, enemy, mode, ball or level type) get one line that says it exists, not a description. When completeness and brevity pull apart, be complete for what the recording uses and brief for the rest.

Write what a programmer would need to make the same game play the same way:

1. **Controls.** Every player input and exactly what it does: press, drag, hold, swipe, keys. Thresholds, sensitivity, clamps, cooldowns, what is ignored (a press on UI), and what happens while there is no input.
2. **Flow.** The states of a play session (start, playing, won, lost, restart or next) and what moves the game from one to the next. Counters and timers: shots, lives, moves, time limits.
3. **Objects.** For each kind of gameplay object: how it moves, what it reacts to (which collisions or triggers, with what, and the result), what it creates or removes, and its numbers. Name the type and, from the source map, the recorded objects that carry it, so the reader can find them in the recording.
4. **Rules and formulas.** Win and lose conditions, scoring, damage, rewards, aiming and launch maths, forces and impulses, spawn rules, random ranges and weights, difficulty and progression. Give formulas in words with their numbers.
5. **Constants.** Every number that shapes how the recorded session plays or feels: the name used in the code, the value, the unit, and what it does. Numbers of content the recording never reaches are left out.
6. **Levels and content.** How a level is defined and the data of the recorded level or levels.
7. **Feel.** What the player sees and when: delays, tween durations and eases, camera follow and shake, pop-ups, which event starts which sound or effect.
8. **Screens in the loop.** The start prompt, what the HUD shows and from which value, the result screen and what its buttons do.

Leave out, with one line in the inventory:

- advertising, analytics, attribution, purchases, sign-in, networking, remote configuration, crash reporting;
- save systems, settings and pause menus, beyond what decides the recorded session (for example which level starts);
- editor tools, tests, debug helpers, generated code;
- layout plumbing: safe-area fitting, canvas scaling, aspect and resolution helpers, generic button effects;
- the inside of libraries (tween engines, pooling, SDKs): say what the game asks them to do, not how they work;
- modes and paths that the recorded level, and the scenes the recording went through, do not reach. One line that they exist is enough.

## Accuracy

- State only what the code does. Where the answer is in data you cannot see (a prefab value that was not recorded, an animation clip, a physics material), say so in one line under "Not in the scripts". Do not guess, and do not hedge everything: a recorded value is a fact.
- A quirk or bug that changes what the player sees gets one line. Others are left out.
- A statement that something never happens (no restart, nothing enters a state) needs a search of all sources before you write it.
- Say each thing once. A rule is described where it belongs, and its row in Constants needs only a few words.
- For a number, say where it is from when it matters: recorded, code (a constant or a starting value set in the code), or a source default that the scene could override.
- Write a number the way the code or the source map has it: 0.35, not 35 percent.
- A number you worked out (a sum of delays, a derived speed) is written with its parts, for example "0.56 s (0.34 + 0.22)".
- Before you finish, check every row of Constants against the source map or the code (searching for the number is enough), and reread the code behind each line of Controls, Flow and Rules that you are not sure of. Correct or delete what does not hold. That is the whole review. Do not start other agents for it unless the sources are more than about 8,000 lines.

## The brief: `_project_behavior.md`

The file is the marker line, the title `# Gameplay logic`, and these sections in this order. Leave out a section that has nothing to say. Write prose and short lists; use a table only where one is named.

| Section | Content |
|-|-|
| `## Game` | One paragraph: what the player does, the goal, how a session ends. |
| `## Controls` | A table with the columns Input, Effect, Rules and numbers. |
| `## Flow` | The session states and what causes each transition. |
| `## Objects` | One short subsection per kind of gameplay object. |
| `## Rules` | Conditions, formulas, counters, randomness. |
| `## Constants` | A table with the columns Name, Value, Unit, What it does, From. |
| `## Levels` | How a level is defined, and the data of the recorded level. |
| `## Feel` | Timings and feedback. |
| `## Screens` | Start, HUD, result. |
| `## Not in the scripts` | What the logic depends on and neither the code nor the recorded values tell. What the recording itself shows (where things are, their size, the camera, the look, the sounds) is not missing. |

Length follows the game: about 1,000 to 2,500 words for a small game, tables included, and up to 4,000 for a large one. Above 4,000 words the check prints a note. What counts is that a rebuild finds what it needs and nothing else. Only when the brief would be longer than that, keep Game, Controls, Flow and Constants in `_project_behavior.md` and move a self-contained system into a topic document named after it (`enemies.md`, `economy.md`). Never write one document per script.

## The inventory: `_index.md`

The file is the marker line, the title `# Script inventory`, and one table that lists every `.cs` file of this folder exactly once, with its path relative to this folder as in the source map:

| Source | Disposition | Document | Note |
|-|-|-|-|
| CannonController.cs | USED | _project_behavior.md | aiming and firing |
| SafeAreaFitter.cs | SKIPPED | - | screen layout only |

`USED`: some of its logic is in the named document, even one line; the note may say what you left out. Name the type of every used source once in that document, so a reader can tell where its logic went. `SKIPPED`: nothing of it is in the documents because a rebuild does not need it, and the note says why in a few words.

## Finish

With the Orvind Exporter launcher (the `orvind-export` skill):

1. Run its `check` command for this job. It applies the recorder's validation without finishing anything. Fix what it rejects and run it again until it passes. Look at each note it prints once: correct what is wrong and leave what is right. A note about a number you worked out goes away when the same line shows its parts in brackets. After corrections you do not need another check: the next step validates again, and a rejection there loses nothing.
2. Run its `complete` command. It signs off the documents for you (it writes the result file described below) and finalizes the session.

Without the launcher:

1. Read `script_processing_job.json` and keep its `token`.
2. Write `script_processing_result.json.tmp` containing `{"v":1,"status":"complete","token":"<token of the job file>"}`, with nothing else in it, and rename it to `script_processing_result.json`. This is your last change in the folder: the result file must be the newest file in it. If you are told afterwards that the output was rejected, fix the Markdown and write the result file again in the same way.

Then, unless the skill you are following says what to report, tell the user in three or four lines: how many sources were used and skipped, which documents you wrote, and anything in the game you could not determine.
