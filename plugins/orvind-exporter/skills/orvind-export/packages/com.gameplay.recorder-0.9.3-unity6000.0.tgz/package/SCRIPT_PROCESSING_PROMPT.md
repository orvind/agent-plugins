# Gameplay Recorder: script logic task

This folder holds the C# scripts of a Unity game, exported next to a recording of that game being played (video, scene, assets, object and input timelines). Another AI will rebuild the game as a small playable ad: the recorded level first, and other levels of the game that a customer can choose. It gets the recording. It never sees these scripts.

Your job: write down, in plain prose and numbers, the game logic and the constants that rebuild needs and that the recording alone cannot show. One short brief, not a document per script.

This is a task of minutes. Read what matters, write the brief, check it, finish.

## Rules that are checked

1. Work only in this folder. Read no other file of the project, upload nothing, and do not change or delete any `.cs` file, this prompt, `SOURCE_MAP.md` or `script_processing_job.json`. Running the Orvind Exporter launcher, when you have it, is fine.
2. Your output is Markdown written directly into this folder: `_index.md` and `_project_behavior.md`. Add a topic document only when the rules below say so.
3. Every Markdown file you write starts with this exact first line:
   `<!-- playable-script-analysis-md-v4 -->`
   A Markdown file that starts with such a marker line is output of an earlier attempt and yours to replace. Leave any other file alone.
4. No source code in your output:
   - no code blocks, no lines of C#, no method signatures, no statements with braces or semicolons;
   - never eight or more words, names or numbers in a row in the order they have on one line of a source. Say it in your own words. When you list names (enum values, fields, cases), do not reproduce a long list in source order: group them, reorder them, or split the sentence. The check compares runs of letters, digits and underscores, ignoring case and punctuation, with every line of every source, comments and strings included;
   - type, field, method, tag, layer and animation names are fine, with or without backticks, and so are numbers.
5. No secrets and no personal data, even when the code contains them: no keys, tokens, passwords, URLs, e-mail addresses, account, bundle or ad-unit identifiers.
6. No absolute file paths. Object names from the source map, such as `Barn/SellPoint/Block(Clone)`, are not file paths and are fine.
7. Finish with the result file, exactly as described under "Finish".

## Start from the source map

`SOURCE_MAP.md`, when present, was written by the recorder for you:

- One row per source: size, declared types, the Unity entry points it has, the kinds of API it touches ("Signals"), which recorded objects carry it, which other sources it uses, and a "Hint" (core, supporting, minor, platform or SDK, editor only). The hint is a guess from the shape of the code. You decide.
- A source without recorded objects is either code the others call into, such as rules, progress, data classes and helpers, or a script of content the recording never showed: the objects of other scenes and prefabs of the game, such as other levels and their enemies. "None left at the end" means its objects were destroyed, or their scene was left, before the recording ended: there are no recorded values for it.
- "Recorded values": what each component held when the recording ended, and the data assets it points at. These are the values the game ran with. Use them. A default written in a source is only a default.
- They are a snapshot of the end of the recording. A field marked "the code changes it during play" (a score, a counter, a timer) shows where it ended, so take its starting value from the code. A field marked "no source reads it" changes nothing: leave it out.
- A reference listed as "not assigned" is empty in the scene. Code that needs that object does nothing there: describe what this scene does, not what the code could do.
- "Built by code": objects and sounds the game makes in code (primitives, meshes made at runtime, `AudioClip.Create`). The recorder exported each one from the running game, so the rebuild has its model or sound file but not what it is for. For each, say in the brief which code builds it, what it is for, and when it appears or plays (the tool of which job, the sound of which event). Do not describe its shape or synthesis: the file has it.

Decide what to read from it:

- Follow the game, not the file list. Start at the player's input, follow what it triggers to the win, the loss and the restart. Then follow the progression: the code that picks the next level, and what each kind of level creates.
- When the sources are under about 1,000 lines in total, read them all and skip the triage.
- Read in full the sources that drive the recorded gameplay and every other level kind, enemy, obstacle and power-up the game's progression reaches. They are usually among those hinted core, but a hint is not a reason to read: a menu or hub controller, a result card or a sound manager can look core and matter for a few lines only.
- Read supporting ones for the events and numbers they add.
- A large source can matter for one small part (a menu controller that also starts the level): read that part and search the rest.
- The rest: when the name, the types and the signals already say what a source is (a safe-area fitter, a canvas scaler, a button effect), do not open it. Otherwise open its first screenful to confirm that it does not change how the game plays.
- Read several files in one step when your tools allow it. This task is mostly reading.

## What the rebuild needs

The scope is the game the player can reach through its own progression: every level, level kind, enemy, obstacle, power-up and mode that the game can start, whether or not the recording reaches it. The rebuild may build any of those levels, so each needs its rules and numbers, not one line. Give the recorded session the most detail (its exact values and its feel) and everything else enough rules, formulas and constants to rebuild it. Only content the progression never starts (test, debug and prototype scenes, unused modes) gets one line.

Write what a programmer would need to make the same game play the same way:

1. **Controls.** Every player input and exactly what it does: press, drag, hold, swipe, keys. Thresholds, sensitivity, clamps, cooldowns, what is ignored (a press on UI), and what happens while there is no input.
2. **Flow.** The states of a play session (start, playing, won, lost, restart or next) and what moves the game from one to the next. Counters and timers: shots, lives, moves, time limits.
3. **Objects.** For each kind of gameplay object: how it moves, what it reacts to (which collisions or triggers, with what, and the result), what it creates or removes, and its numbers. Name the type and, from the source map, the recorded objects that carry it, so the reader can find them in the recording.
4. **Rules and formulas.** Win and lose conditions, scoring, damage, rewards, aiming and launch maths, forces and impulses, spawn rules, random ranges and weights, difficulty and progression. Give formulas in words with their numbers.
5. **Constants.** Every number that shapes how a reachable level plays or feels: the name used in the code, the value, the unit, and what it does. Say which level kinds a number applies to when it differs between them (a power that lasts less in one kind of level).
6. **Levels and content.** How a level is defined and where its data lives (assets, data files, scenes, or tables and formulas in code); the list of levels, or the rule that generates it; and for each level kind and encounter its layout, spawn schedule, enemies, timings and numbers. Authored data written in the code is restated in full (see "Content written in the code"). Then name the level the recording played and the evidence for it.
7. **Feel.** What the player sees and when: delays, tween durations and eases, camera follow and shake, pop-ups, which event starts which sound or effect.
8. **Screens in the loop.** The start prompt, what the HUD shows and from which value, the result screen and what its buttons do.

Leave out, with one line in the inventory:

- advertising, analytics, attribution, purchases, sign-in, networking, remote configuration, crash reporting;
- save systems, settings and pause menus, beyond what decides which level starts and what the progression unlocks;
- editor tools, tests, debug helpers, generated code;
- layout plumbing: safe-area fitting, canvas scaling, aspect and resolution helpers, generic button effects;
- the inside of libraries (tween engines, pooling, SDKs): say what the game asks them to do, not how they work;
- test, debug and prototype scenes and modes that the game's progression never starts. One line that they exist is enough.

## Content written in the code

Some games write what the player meets into the code: literal arrays and lists, lists built from literals, switch cases that return fixed values, strings that are decoded into content, one constant per case. It may describe levels, waves, spawn schedules, layouts, enemy rosters, shop items, cards or anything else the player plays through. A rebuild cannot see the code, so this data reaches it only through you:

- Restate every entry, in your own layout: one table row per entry, with the columns in a different order from the source and the type and field names as column headers. A summary ("five layouts", "the others in brief", "and so on") loses the content.
- When the code computes values from an entry (a scale, a mirror, a per-level offset), restate the entry once and give the formula with its inputs; do not list computed values row by row.
- Put these tables in a topic document `content.md` when they are longer than about a page. Its length does not count toward the brief's length.
- A game with no such data has nothing to restate.

When a rule's effect, duration or number changes with the mode, the kind of level or the game's state (a power-up that acts differently in two kinds of level, a speed that depends on a difficulty), give it for each case.

## Accuracy

- State only what the code does. Where the answer is in data you cannot see (a prefab value that was not recorded, an animation clip, a physics material), say so in one line under "Not in the scripts". Do not guess, and do not hedge everything: a recorded value is a fact.
- A quirk or bug that changes what the player sees gets one line. Others are left out.
- A statement that something never happens (no restart, nothing enters a state) needs a search of all sources before you write it.
- Decide which level, mode or content the recording played from the recording itself (the frames, the HUD text, the play summary, when you have them), from the recorded values and from the objects that carry the scripts, never from saved progress alone: a save tells which level the menu offered, not which one was played. Say which evidence decided it. When it stays unclear, say so.
- Say each thing once. A rule is described where it belongs, and its row in Constants needs only a few words.
- For a number, say where it is from when it matters: recorded, code (a constant or a starting value set in the code), or a source default that the scene could override.
- Write a number the way the code or the source map has it: 0.35, not 35 percent.
- A number you worked out (a sum of delays, a derived speed) is written with its parts, for example "0.56 s (0.34 + 0.22)".
- Before you finish, check every row of Constants against the source map or the code (searching for the number is enough), and reread the code behind each line of Controls, Flow and Rules that you are not sure of. Correct or delete what does not hold. That is the whole review. Do not start other agents for it unless the sources are more than about 8,000 lines.

## The brief: `_project_behavior.md`

The file is the marker line, the title `# Gameplay logic`, and these sections in this order. Leave out a section that has nothing to say. Write prose and short lists; use a table only where one is named.

| Section | Content |
|-|-|
| `## Game` | One paragraph: what the player does, the goal, how a session ends. |
| `## Controls` | A table with the columns Input, Effect, Rules and numbers. |
| `## Flow` | The session states and what causes each transition. |
| `## Objects` | One short subsection per kind of gameplay object. |
| `## Rules` | Conditions, formulas, counters, randomness. |
| `## Constants` | A table with the columns Name, Value, Unit, What it does, From. |
| `## Levels` | How a level is defined, every level or the rule that generates them, the data of each level kind and encounter, and which level was recorded. |
| `## Feel` | Timings and feedback. |
| `## Screens` | Start, HUD, result. |
| `## Content data` | One row per authored data structure in the code (see "Content written in the code"): its type or member name, what it holds, and the section or document that restates it, or why a rebuild does not need it. Write "None" when the code holds none. |
| `## Not in the scripts` | What the logic depends on and neither the code nor the recorded values tell. What the recording itself shows (where things are, their size, the camera, the look, the sounds) is not missing. |

Length follows the game: about 1,000 to 2,500 words for a small game with one kind of level, tables included, and more for each further level kind, up to about 8,000 in all, not counting `content.md`. Above that the check prints a note. What counts is that a rebuild finds what it needs and nothing else: say each rule once, and give a formula with its inputs instead of a row per level where the code computes the values. When the brief grows beyond about 4,000 words, keep Game, Controls, Flow and Constants in `_project_behavior.md` and move each level kind or self-contained system into a topic document named after it (`levels.md`, `enemies.md`, `economy.md`). Never write one document per script.

## The inventory: `_index.md`

The file is the marker line, the title `# Script inventory`, and one table that lists every `.cs` file of this folder exactly once, with its path relative to this folder as in the source map:

| Source | Disposition | Document | Note |
|-|-|-|-|
| CannonController.cs | USED | _project_behavior.md | aiming and firing |
| SafeAreaFitter.cs | SKIPPED | - | screen layout only |

`USED`: some of its logic is in the named document, even one line; the note may say what you left out. Name the type of every used source once in that document, so a reader can tell where its logic went. `SKIPPED`: nothing of it is in the documents because a rebuild does not need it, and the note says why in a few words. A source that implements a level, level kind, enemy, obstacle, power-up or mode the game's progression reaches is never SKIPPED, even when the recording does not show it.

## Finish

With the Orvind Exporter launcher (the `orvind-export` skill):

1. Run its `check` command for this job. It applies the recorder's validation without finishing anything. Fix what it rejects and run it again until it passes. Look at each note it prints once: correct what is wrong and leave what is right. A note about a number you worked out goes away when the same line shows its parts in brackets. After corrections you do not need another check: the next step validates again, and a rejection there loses nothing.
2. Run its `complete` command. It signs off the documents for you (it writes the result file described below) and finalizes the session.

Without the launcher:

1. Read `script_processing_job.json` and keep its `token`.
2. Write `script_processing_result.json.tmp` containing `{"v":1,"status":"complete","token":"<token of the job file>"}`, with nothing else in it, and rename it to `script_processing_result.json`. This is your last change in the folder: the result file must be the newest file in it. If you are told afterwards that the output was rejected, fix the Markdown and write the result file again in the same way.

Then, unless the skill you are following says what to report, tell the user in three or four lines: how many sources were used and skipped, which documents you wrote, and anything in the game you could not determine.
